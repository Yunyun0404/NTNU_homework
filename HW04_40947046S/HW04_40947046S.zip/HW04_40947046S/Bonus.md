#### Bonus

rm *.c就是把當前資料夾所有.c檔刪掉

![image-20220503180052708](C:\Users\User\AppData\Roaming\Typora\typora-user-images\image-20220503180052708.png)

根據圖片，我的 test 資料夾本來有三個.c檔，我下完指令之後，他們就被我刪掉了。